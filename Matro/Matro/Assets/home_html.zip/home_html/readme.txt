Native交互的地方请看 scripts/matrojp.app.native.js 中的定义

TODO 目前待确认的问题
1. 接口返回中没有定义ID是否用现有的idx
2. 首页中有个广告区域没有接口定义，是否放静态图
